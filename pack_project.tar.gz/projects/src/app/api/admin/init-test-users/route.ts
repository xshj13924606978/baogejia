import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 初始化测试账号
export async function POST(request: NextRequest) {
  try {
    const db = getSupabaseClient();

    const testUsers = [
      {
        username: 'admin',
        password: '123456',
        email: 'admin@baojia.com',
        role: 'super_admin',
        points: 9999,
        total_points: 9999,
        status: 'active',
        verified: true,
        quota_used: 0,
        quota_total: 9999,
      },
      {
        username: 'vip',
        password: '123456',
        email: 'vip@baojia.com',
        role: 'vip',
        points: 500,
        total_points: 500,
        status: 'active',
        verified: true,
        quota_used: 0,
        quota_total: 9999,
        expire_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      },
      {
        username: 'factory',
        password: '123456',
        email: 'factory@baojia.com',
        role: 'manufacturer',
        company: '示例制造厂',
        contact: '张三',
        points: 300,
        total_points: 300,
        status: 'active',
        verified: true,
        quota_used: 0,
        quota_total: 10,
      },
      {
        username: 'user',
        password: '123456',
        email: 'user@baojia.com',
        role: 'user',
        points: 100,
        total_points: 100,
        status: 'active',
        verified: true,
        quota_used: 0,
        quota_total: 10,
      },
    ];

    const results: any[] = [];

    for (const testUser of testUsers) {
      // 检查用户是否已存在
      const { data: existingUser } = await db
        .from('users')
        .select('id')
        .eq('username', testUser.username)
        .single();

      if (existingUser) {
        // 更新现有用户
        const { data: updatedUser, error: updateError } = await db
          .from('users')
          .update(testUser)
          .eq('username', testUser.username)
          .select()
          .single();

        if (updateError) {
          console.error(`[Init] 更新用户 ${testUser.username} 失败:`, updateError);
        } else {
          results.push({ username: testUser.username, action: 'updated', id: updatedUser.id });
        }
      } else {
        // 创建新用户
        const { data: newUser, error: createError } = await db
          .from('users')
          .insert(testUser)
          .select()
          .single();

        if (createError) {
          console.error(`[Init] 创建用户 ${testUser.username} 失败:`, createError);
        } else {
          results.push({ username: testUser.username, action: 'created', id: newUser.id });
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: '测试账号初始化完成',
      results
    });
  } catch (error) {
    console.error('[Init] 初始化测试账号失败:', error);
    return NextResponse.json(
      { error: '服务器错误' },
      { status: 500 }
    );
  }
}
